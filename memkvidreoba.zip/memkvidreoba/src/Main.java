public class Main {
    public static void main(String[] args) {
        //1
//        Human human = new Human("Aaaa", "Bbbbb", 35) ;
//        human.introduce();
//
//        Employee tanamshromeli = new Employee("Ccc", "Ddd", 28, "1234567");
//        tanamshromeli.introduce();
//
//        Manager menejeri = new Manager("Eee", "Fff", 40, "8910111", "001");
//        menejeri.introduce();

        //2
//        Circle circle = new Circle(5);
//        System.out.println("Circle Area: " + circle.getArea());
//        System.out.println("Circle Perimeter: " + circle.getPerimeter());
//
//        Rectangle rectangle = new Rectangle(4, 3);
//        System.out.println("Rectangle Area: " + rectangle.getArea());
//        System.out.println("Rectangle Perimeter: " + rectangle.getPerimeter());
//        System.out.println("Rectangle Diagonal: " + rectangle.getDiagonal());
//
//        Triangle triangle = new Triangle(3, 4, 5);
//        System.out.println("Triangle Area: " + triangle.getArea());
//        System.out.println("Triangle Perimeter: " + triangle.getPerimeter());

        //3
//        Store store = new Store();
//
//        Milk milk = new Milk(2.5, "2024-12-31", 1.0);
//        Cake cake = new Cake(5.0, "2024-12-20", 0.5);
//        Sandwich sandwich = new Sandwich(3.0, "2024-12-15", 15.0);
//
//        store.addProduct(milk);
//        store.addProduct(cake);
//        store.addProduct(sandwich);
//
//        for (Product product : store.getProducts()) {
//            if (product instanceof Milk) {
//                Milk milk1 = (Milk) product;
//                System.out.println("Milk - Price: " + milk1.getPrice() + ", Expiry Date: " + milk1.getExpiryDate() + ", Volume: " + milk1.getVolume());
//            } else if (product instanceof Cake) {
//                Cake cake1 = (Cake) product;
//                System.out.println("Cake - Price: " + cake1.getPrice() + ", Expiry Date: " + cake1.getExpiryDate() + ", Weight: " + cake1.getWeight());
//            } else if (product instanceof Sandwich) {
//                Sandwich sandwich1 = (Sandwich) product;
//                System.out.println("Sandwich - Price: " + sandwich1.getPrice() + ", Expiry Date: " + sandwich1.getExpiryDate() + ", Length: " + sandwich1.getLength());
//            }
//        }
    }
}