package human;

public class Manager extends Employee {
    private String manajerID;

    public Manager(String name, String lastName, int age, String employeeID, String manajerID) {
        super(name, lastName, age, employeeID);
        this.manajerID = manajerID;
    }

    public String getManajerID() {
        return manajerID;
    }

    public void setManajerID(String manajerID) {
        this.manajerID = manajerID;
    }

    @Override
    public void introduce() {
        super.introduce();
        System.out.println("მენეჯერის ID: " + manajerID);
    }
}
