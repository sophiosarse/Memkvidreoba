package human;

public class Employee extends Human {
    private String employeeID;
    public Employee(String name, String lastName, int age, String employeeID) {
        super(name, lastName, age);
        this.employeeID = employeeID;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    @Override
    public void introduce() {
        super.introduce();
        System.out.println("თანამშრომლის ID: " + employeeID);
    }
}
